/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.table('venta', function(table) {
        table.dropColumn('cliente_id');
    });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.table('venta', function(table) {
        table.integer('cliente_id').unsigned().notNullable();
    });
};
